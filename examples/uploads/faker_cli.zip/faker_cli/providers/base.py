class BaseProvider:
    pass
