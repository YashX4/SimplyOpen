"""
Mini EC2 — Docker Edition
=========================

A tiny, self-hosted clone of AWS EC2's core experience, backed by Docker
containers instead of real virtual machines. Each "instance" you launch here is
a Docker container with CPU/memory limits, an "instance type", and an "image"
chosen from a small catalog — mirroring how EC2 exposes instance types and AMIs.

This file is the API layer: a FastAPI app that translates friendly, EC2-style
REST calls into Docker SDK operations. The React UI in ./mini-ec2-ui talks to it.

Run it with:
    uvicorn main:app --reload
Then open http://127.0.0.1:8000/docs for the interactive API explorer.
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import docker
from docker.errors import DockerException, NotFound, APIError, ImageNotFound

app = FastAPI(
    title="Mini EC2 — Docker Edition",
    version="1.0.0",
    description="A self-hosted, EC2-style control plane for Docker containers, built to teach how a cloud VM API works.",
)

# Allow the React dev/preview server (on a different port) to call this API.
# Vite serves on 5173 (dev) and 4173 (preview); we accept any localhost port so
# the project keeps working if you change ports.
app.add_middleware(
    CORSMiddleware,
    allow_origin_regex=r"http://(localhost|127\.0\.0\.1):\d+",
    allow_methods=["*"],
    allow_headers=["*"],
)


# --- Lazy Docker client -----------------------------------------------------
# We connect to the Docker daemon on first use, not at import time, so the API
# still boots (and can report a friendly error) when Docker isn't running yet.
_client = None


def get_client():
    """Return a cached Docker client, or raise a clean 503 if the daemon is
    unreachable — instead of crashing every request with a raw stack trace."""
    global _client
    if _client is None:
        try:
            candidate = docker.from_env()
            candidate.ping()  # actually talk to the daemon so we fail fast
            _client = candidate
        except Exception as e:  # DockerException, connection errors, etc.
            raise HTTPException(
                status_code=503,
                detail=f"Can't reach the Docker daemon. Is Docker running? ({e})",
            )
    return _client


# --- Instance type presets, mirroring EC2's t3 family -----------------------
# vcpus is converted to Docker's nano_cpus (1 vCPU = 1_000_000_000 nano_cpus)
# memory_mb is converted to Docker's mem_limit (e.g. "512m")
INSTANCE_TYPES = {
    "t3.micro":  {"vcpus": 1, "memory_mb": 256,  "description": "1 vCPU, 256 MB — small test services"},
    "t3.small":  {"vcpus": 1, "memory_mb": 512,  "description": "1 vCPU, 512 MB — light workloads"},
    "t3.medium": {"vcpus": 2, "memory_mb": 1024, "description": "2 vCPU, 1 GB — general purpose"},
    "t3.large":  {"vcpus": 2, "memory_mb": 2048, "description": "2 vCPU, 2 GB — heavier workloads"},
}
DEFAULT_INSTANCE_TYPE = "t3.micro"


# --- Image catalog — a curated set of images, like a mini AMI list ----------
# internal_port is the port the app listens on INSIDE the container (None if not a network service).
# command overrides the image's default command — needed for images like plain ubuntu
# that otherwise exit immediately after starting (no long-running process to keep alive).
IMAGE_CATALOG = {
    "nginx": {
        "image": "nginx:latest",
        "internal_port": 80,
        "description": "Nginx web server — serves a default welcome page out of the box",
    },
    "httpd": {
        "image": "httpd:latest",
        "internal_port": 80,
        "description": "Apache web server (httpd)",
    },
    "whoami": {
        "image": "traefik/whoami",
        "internal_port": 80,
        "description": "Tiny test server that echoes back request details — good for quick checks",
    },
    "redis": {
        "image": "redis:alpine",
        "internal_port": 6379,
        "description": "Redis in-memory data store / cache",
    },
    "ubuntu": {
        "image": "ubuntu:latest",
        "internal_port": None,
        "command": "sleep infinity",
        "description": "Blank Ubuntu box with no web server — exec into it with docker exec",
    },
}
DEFAULT_IMAGE_KEY = "nginx"


# --- Request body schema for creating an instance ---------------------------
class CreateInstanceRequest(BaseModel):
    name: str
    image_key: str = DEFAULT_IMAGE_KEY
    port: int = 8080
    instance_type: str = DEFAULT_INSTANCE_TYPE


# --- Helper: turn a docker Container object into a clean dict for API responses
def serialize_container(container):
    # host_port is stored as a label at launch time so we can rebuild the URL
    # you'd use to reach the service, without re-inspecting the port bindings.
    host_port = container.labels.get("host_port")
    try:
        image_tag = container.image.tags[0] if container.image.tags else "unknown"
    except Exception:
        image_tag = "unknown"
    return {
        "name": container.name,
        "id": container.short_id,
        "status": container.status,
        "image": image_tag,
        "image_key": container.labels.get("image_key", "custom"),
        "instance_type": container.labels.get("instance_type", "custom"),
        "port": int(host_port) if host_port else None,
        "url": f"http://localhost:{host_port}" if host_port else None,
    }


@app.get("/")
def root():
    """Tiny landing payload so hitting the API root isn't a 404."""
    return {
        "service": "Mini EC2 — Docker Edition",
        "docs": "/docs",
        "endpoints": ["/health", "/instance-types", "/images", "/instances"],
    }


@app.get("/health")
def health():
    """Report whether the API is up and whether it can reach Docker.
    Always returns 200 so the UI can render a status dot instead of erroring."""
    try:
        get_client()
        return {"api": "ok", "docker": True, "detail": "connected"}
    except HTTPException as e:
        return {"api": "ok", "docker": False, "detail": e.detail}


@app.get("/instance-types")
def list_instance_types():
    return [
        {"name": name, **specs} for name, specs in INSTANCE_TYPES.items()
    ]


@app.get("/images")
def list_images():
    return [
        {"key": key, **{k: v for k, v in specs.items() if k != "command"}}
        for key, specs in IMAGE_CATALOG.items()
    ]


@app.post("/instances")
def create_instance(req: CreateInstanceRequest):
    client = get_client()

    # Check for name collision first, since Docker's error message is unfriendly otherwise
    existing = [c.name for c in client.containers.list(all=True)]
    if req.name in existing:
        raise HTTPException(status_code=400, detail=f"Instance '{req.name}' already exists")

    if req.instance_type not in INSTANCE_TYPES:
        valid = ", ".join(INSTANCE_TYPES.keys())
        raise HTTPException(
            status_code=400,
            detail=f"Unknown instance type '{req.instance_type}'. Valid types: {valid}",
        )

    if req.image_key not in IMAGE_CATALOG:
        valid = ", ".join(IMAGE_CATALOG.keys())
        raise HTTPException(
            status_code=400,
            detail=f"Unknown image '{req.image_key}'. Valid images: {valid}",
        )

    specs = INSTANCE_TYPES[req.instance_type]
    nano_cpus = specs["vcpus"] * 1_000_000_000
    mem_limit = f"{specs['memory_mb']}m"

    image_entry = IMAGE_CATALOG[req.image_key]

    # Map the container's internal port to the host port the user asked for.
    labels = {"instance_type": req.instance_type, "image_key": req.image_key}
    ports = None
    if image_entry["internal_port"] is not None:
        ports = {f"{image_entry['internal_port']}/tcp": req.port}
        labels["host_port"] = str(req.port)

    try:
        container = client.containers.run(
            image_entry["image"],
            name=req.name,
            command=image_entry.get("command"),
            ports=ports,
            detach=True,
            nano_cpus=nano_cpus,
            mem_limit=mem_limit,
            labels=labels,
        )
    except ImageNotFound:
        raise HTTPException(
            status_code=404,
            detail=f"Image '{image_entry['image']}' isn't downloaded yet. "
                   f"Run: docker pull {image_entry['image']}",
        )
    except APIError as e:
        msg = str(e)
        if "port is already allocated" in msg:
            raise HTTPException(
                status_code=409,
                detail=f"Port {req.port} is already in use — pick a different port.",
            )
        raise HTTPException(status_code=500, detail=msg)

    return serialize_container(container)


@app.get("/instances")
def list_instances():
    client = get_client()
    containers = client.containers.list(all=True)
    return [serialize_container(c) for c in containers]


@app.get("/instances/{name}")
def get_instance(name: str):
    client = get_client()
    try:
        container = client.containers.get(name)
    except NotFound:
        raise HTTPException(status_code=404, detail=f"Instance '{name}' not found")
    return serialize_container(container)


@app.get("/instances/{name}/logs")
def get_instance_logs(name: str, tail: int = 100):
    """Return the last `tail` lines of the container's output — the mini-EC2
    equivalent of 'get console output' for an instance."""
    client = get_client()
    try:
        container = client.containers.get(name)
    except NotFound:
        raise HTTPException(status_code=404, detail=f"Instance '{name}' not found")
    raw = container.logs(tail=tail)
    return {"name": name, "logs": raw.decode("utf-8", errors="replace")}


@app.post("/instances/{name}/stop")
def stop_instance(name: str):
    client = get_client()
    try:
        container = client.containers.get(name)
    except NotFound:
        raise HTTPException(status_code=404, detail=f"Instance '{name}' not found")
    container.stop()
    return {"message": f"Instance '{name}' stopped"}


@app.post("/instances/{name}/start")
def start_instance(name: str):
    client = get_client()
    try:
        container = client.containers.get(name)
    except NotFound:
        raise HTTPException(status_code=404, detail=f"Instance '{name}' not found")
    container.start()
    return {"message": f"Instance '{name}' started"}


@app.delete("/instances/{name}")
def delete_instance(name: str):
    client = get_client()
    try:
        container = client.containers.get(name)
    except NotFound:
        raise HTTPException(status_code=404, detail=f"Instance '{name}' not found")
    container.remove(force=True)
    return {"message": f"Instance '{name}' deleted"}
