# Mini EC2 — Docker Edition

> A tiny, self-hosted clone of AWS EC2's core experience — built to **learn how a cloud VM control plane actually works** by building one.

You launch "instances", pick an "instance type" (`t3.micro`, `t3.small`, …) and an
"image" from a small catalog, then start / stop / delete them from a web console.
Under the hood there are no virtual machines and no AWS account — each "instance"
is just a **Docker container** with CPU and memory limits. Same mental model as
EC2, running entirely on your laptop, with code small enough to read in one sitting.

<p align="center">
  <em>React console → FastAPI control plane → Docker Engine → containers</em>
</p>

---

## Why this exists

Cloud platforms like EC2 feel like magic: click a button, get a running server.
This project pulls back the curtain. The fastest way to understand a system is to
build the smallest version of it that still does the real thing — so instead of a
slide deck about "instances" and "AMIs", you get a working control plane you can
launch, break, and read top to bottom.

The goal is **education**: to show that "launch an instance" is, at heart, one API
call translating a friendly request into an engine operation — and that you can
build your own EC2-shaped API over any backend. Here the backend is Docker because
it runs anywhere; the [roadmap](self-hosted-ec2-roadmap.md) sketches how the exact
same API layer could sit on top of **real VMs** (KVM/libvirt) later.

## The analogy at a glance

| AWS EC2 | Mini EC2 (this project) | Where it lives |
| --- | --- | --- |
| Instance (a VM) | A Docker container | Docker Engine |
| Instance type (`t3.micro`) | CPU + memory limits preset | `INSTANCE_TYPES` in `main.py` |
| AMI (machine image) | Image from a small catalog | `IMAGE_CATALOG` in `main.py` |
| Launch / Terminate | `POST` / `DELETE /instances` | FastAPI + Docker SDK |
| Start / Stop | `POST /instances/{name}/start`·`/stop` | FastAPI + Docker SDK |
| Get console output | `GET /instances/{name}/logs` | `container.logs()` |
| EC2 Console (web UI) | The React "instance console" | `mini-ec2-ui/` |
| Control plane API | The FastAPI app | `main.py` |

It is **not** a real cloud: no real VMs, no isolation guarantees, no persistence
layer, no auth. That's the point — it's the smallest thing that teaches the shape.

## Architecture

```
┌─────────────────────┐     HTTP/JSON      ┌────────────────────┐   Docker SDK   ┌───────────────┐
│  React UI (Vite)    │  ───────────────▶  │  FastAPI (main.py) │  ───────────▶  │ Docker Engine │
│  mini-ec2-ui/       │  ◀───────────────  │  the control plane │  ◀───────────  │  containers   │
│  :5173              │                    │  :8000             │                │  = "instances"│
└─────────────────────┘                    └────────────────────┘                └───────────────┘
```

- **`main.py`** — the control plane. Translates EC2-style REST calls into Docker
  operations, and maps instance types to real resource limits.
- **`mini-ec2-ui/`** — a terminal-styled React console that calls the API and polls
  for status.
- **`vm_manager.py`** — the ~30-line prototype the API grew out of, kept as a
  teaching artifact.

## Prerequisites

- **Docker Desktop / Docker Engine**, running.
- **Python 3.9+**
- **Node 18+** (for the UI)

## Quickstart

**1. Start the API (control plane):**

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload
```

The API is now at `http://127.0.0.1:8000`. Open `http://127.0.0.1:8000/docs` for
the auto-generated, interactive API explorer.

**2. Start the web console (in a second terminal):**

```bash
cd mini-ec2-ui
npm install
npm run dev
```

Open `http://localhost:5173` and launch your first instance. Pick `nginx`, port
`8080`, then click the instance's link to see it serving at `http://localhost:8080`.

> The header shows a **docker up / down** dot. If Docker isn't running, the API
> still boots and every endpoint returns a clear message instead of crashing.

## Try it without the UI

```bash
# List the "AMIs" and "instance types"
curl localhost:8000/images
curl localhost:8000/instance-types

# Launch an nginx instance on port 8080
curl -X POST localhost:8000/instances \
  -H 'Content-Type: application/json' \
  -d '{"name":"web-1","image_key":"nginx","port":8080,"instance_type":"t3.micro"}'

curl localhost:8000/instances              # list
curl localhost:8000/instances/web-1/logs   # "console output"
curl -X POST localhost:8000/instances/web-1/stop
curl -X DELETE localhost:8000/instances/web-1
```

## API reference

| Method | Path | Purpose |
| --- | --- | --- |
| `GET` | `/health` | API status + whether Docker is reachable |
| `GET` | `/instance-types` | List instance-type presets |
| `GET` | `/images` | List the image catalog (mini "AMI" list) |
| `POST` | `/instances` | Launch an instance |
| `GET` | `/instances` | List all instances |
| `GET` | `/instances/{name}` | Get one instance |
| `GET` | `/instances/{name}/logs` | Fetch console output (`?tail=100`) |
| `POST` | `/instances/{name}/start` | Start a stopped instance |
| `POST` | `/instances/{name}/stop` | Stop a running instance |
| `DELETE` | `/instances/{name}` | Terminate an instance |

**Launch request body:**

```json
{
  "name": "web-1",
  "image_key": "nginx",
  "port": 8080,
  "instance_type": "t3.micro"
}
```

## How the mapping works

When you launch an instance, `main.py` does three small translations:

1. **Instance type → resource limits.** `t3.micro` looks up `{vcpus: 1, memory_mb: 256}`
   and converts it to Docker's `nano_cpus` (`1 vCPU = 1_000_000_000`) and
   `mem_limit` (`"256m"`). That's how the container is actually capped.
2. **Image key → image + ports.** `nginx` resolves to `nginx:latest` listening on
   internal port `80`, mapped to the host port you requested. Non-network images
   (like `ubuntu`) publish no port and use `sleep infinity` to stay alive.
3. **Metadata → labels.** The instance type, image key, and published port are
   stored as Docker **labels** so the API can reconstruct each instance's details
   (and its URL) just by listing containers — no separate database needed.

## Project structure

```
custom-ec2/
├── main.py                     # FastAPI control plane (the core)
├── vm_manager.py               # the original ~30-line prototype
├── requirements.txt            # Python dependencies
├── mini-ec2-ui/                # React + Vite web console
│   └── src/App.jsx             # the whole UI
├── self-hosted-ec2-roadmap.md  # path from Docker → real VMs (KVM/libvirt)
├── docker-commands.md          # handy raw docker commands
└── website/                    # the explainer site (open website/index.html)
```

## Limitations (by design)

This is a learning tool, not infrastructure. It has no authentication, no real VM
isolation, no persistence beyond Docker itself, and no multi-host scheduling.
Run it locally, read the code, and use it to reason about how the real thing works.

## Where it goes next

See [`self-hosted-ec2-roadmap.md`](self-hosted-ec2-roadmap.md) for the path from
"Docker containers pretending to be VMs" to a genuinely self-hosted VM platform on
KVM/libvirt — where this same API layer would create real virtual machines with
their own kernels, disks, and IPs.
