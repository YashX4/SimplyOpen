# Self-Hosted EC2-Style VM Platform — Project Roadmap

**Goal:** Build a small self-hosted VM platform for personal/team use, using KVM/libvirt
as the hypervisor engine and a custom-built API/UI layer on top (your own "EC2").

**Starting point:** New to virtualization/infra, learning as you go.

---

## Milestone 0: Prep the host
- A Linux box (bare metal or a VM with nested virtualization enabled)
- Check virtualization support: `egrep -c '(vmx|svm)' /proc/cpuinfo` (should be > 0)
- Recommended OS: Ubuntu Server 22.04 or 24.04

## Milestone 1: Get ONE VM running manually via KVM/libvirt
- Install: `qemu-kvm`, `libvirt-daemon-system`, `virtinst`, `bridge-utils`
- Use `virt-install` with an Ubuntu cloud image (supports `cloud-init` for
  auto-configuring hostname/SSH keys, similar to EC2 user-data)
- **Checkpoint:** SSH into a VM you created from the command line

## Milestone 2: Networking so VMs get real IPs
- Set up a Linux bridge (`br0`) on the physical NIC, or start with libvirt's
  built-in NAT network for simplicity
- **Checkpoint:** VMs get DHCP leases, can reach the internet, and are reachable from your LAN

## Milestone 3: Wrap VM creation in a script
- Python script using `libvirt` Python bindings (or shelling out to `virsh`/`virt-install`)
- Takes parameters: name, CPU, RAM, disk size, image
- This script is the seed of your "EC2 API"

## Milestone 4: Turn the script into an API
- Small FastAPI (Python) or Express (Node) app
- Endpoints:
  - `POST /instances` — create VM
  - `GET /instances` — list VMs
  - `DELETE /instances/{id}` — destroy VM
  - `POST /instances/{id}/stop` / `/start`
- Store VM metadata (name, IP, status, created_at) in SQLite or Postgres

## Milestone 5: Basic web UI
- Simple frontend hitting your API
- Launch button, instance list, status view

## Milestone 6 (stretch): EC2-like niceties
- "Instance types" as presets (e.g. t3.micro = 1 vCPU / 1GB RAM)
- Image templates (Ubuntu/Debian/etc.)
- SSH key injection via cloud-init
- Basic console access (VNC/serial through libvirt)

---

**Next step:** Milestone 1 — exact commands for getting the first VM running via
`virt-install` on an Ubuntu Server host.
