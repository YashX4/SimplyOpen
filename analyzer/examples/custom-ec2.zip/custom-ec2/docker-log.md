python3 vm_manager.py
Created instance 'test-instance-1' (id: 40b7883d03a4)
test-instance-1 | running | ['nginx:latest']
my-nginx | exited | ['nginx:latest']
mystifying_einstein | exited | ['hello-world:latest']
admiring_bell | exited | ['hello-world:latest']