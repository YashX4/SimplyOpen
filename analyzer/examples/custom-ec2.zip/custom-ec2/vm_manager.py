"""
vm_manager.py — the prototype that main.py grew out of.

Before the FastAPI service existed, this tiny script was the whole "EC2": a few
functions that shell out to the Docker SDK to create, list, stop, and delete
"instances" (containers). It's kept here as a teaching artifact so you can see
the smallest possible version of the idea before the API and UI were layered on.

Run it directly for a safe, self-contained demo:
    python3 vm_manager.py
It creates one demo instance, lists what's running, then cleans up ONLY the
instance it created.
"""

import docker

client = docker.from_env()


def create_instance(name, image="nginx", port=8080):
    container = client.containers.run(
        image,
        name=name,
        ports={"80/tcp": port},
        detach=True,
    )
    print(f"Created instance '{name}' (id: {container.short_id})")
    return container


def list_instances():
    for c in client.containers.list(all=True):
        tags = c.image.tags or ["<none>"]
        print(f"{c.name} | {c.status} | {tags[0]}")


def stop_instance(name):
    container = client.containers.get(name)
    container.stop()
    print(f"Stopped '{name}'")


def delete_instance(name):
    container = client.containers.get(name)
    container.remove(force=True)
    print(f"Deleted '{name}'")


if __name__ == "__main__":
    demo_name = "demo-box"

    # Start clean in case a previous demo run left the box behind.
    try:
        delete_instance(demo_name)
    except docker.errors.NotFound:
        pass

    create_instance(demo_name, port=8080)
    print("\nCurrent instances:")
    list_instances()

    # Only ever remove the instance this demo created.
    print()
    delete_instance(demo_name)
