docker ps                # list running containers
docker ps -a              # list ALL containers (including stopped)
docker stop my-nginx      # stop it
docker start my-nginx     # start it again
docker logs my-nginx      # see its output/logs
docker rm my-nginx        # delete it (must be stopped first)
docker images             # list downloaded images