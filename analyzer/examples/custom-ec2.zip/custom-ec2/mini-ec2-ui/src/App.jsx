import { useState, useEffect, useCallback } from 'react'

const API_BASE = 'http://127.0.0.1:8000'

export default function App() {
  const [instances, setInstances] = useState([])
  const [instanceTypes, setInstanceTypes] = useState([])
  const [images, setImages] = useState([])
  const [health, setHealth] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [creating, setCreating] = useState(false)
  const [busyName, setBusyName] = useState(null)
  const [logs, setLogs] = useState(null) // { name, text, loading }

  const [form, setForm] = useState({ name: '', image_key: 'nginx', port: '8080', instance_type: 't3.micro' })

  const fetchStatic = useCallback(async () => {
    try {
      const [typesRes, imagesRes] = await Promise.all([
        fetch(`${API_BASE}/instance-types`),
        fetch(`${API_BASE}/images`),
      ])
      if (typesRes.ok) setInstanceTypes(await typesRes.json())
      if (imagesRes.ok) setImages(await imagesRes.json())
    } catch (e) {
      // Non-fatal — the form falls back to sensible defaults if this fails.
    }
  }, [])

  const fetchHealth = useCallback(async () => {
    try {
      const res = await fetch(`${API_BASE}/health`)
      setHealth(await res.json())
    } catch {
      setHealth(null)
    }
  }, [])

  const fetchInstances = useCallback(async () => {
    try {
      const res = await fetch(`${API_BASE}/instances`)
      if (res.status === 503) {
        // Docker is down — the dedicated banner already explains this, so we
        // don't also show the misleading "is main.py running?" message.
        setInstances([])
        setError(null)
        return
      }
      if (!res.ok) throw new Error(`API returned ${res.status}`)
      const data = await res.json()
      setInstances(data)
      setError(null)
    } catch (e) {
      setError(`Can't reach the API at ${API_BASE}. Is main.py running? (${e.message})`)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchStatic()
    fetchHealth()
    fetchInstances()
    const interval = setInterval(() => {
      fetchInstances()
      fetchHealth()
    }, 4000) // poll for status changes
    return () => clearInterval(interval)
  }, [fetchStatic, fetchHealth, fetchInstances])

  const selectedImage = images.find((i) => i.key === form.image_key)
  const isNetworkService = !selectedImage || selectedImage.internal_port !== null

  async function handleCreate(e) {
    e.preventDefault()
    if (!form.name.trim()) return
    setCreating(true)
    setError(null)
    try {
      const res = await fetch(`${API_BASE}/instances`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: form.name.trim(),
          image_key: form.image_key,
          port: parseInt(form.port, 10) || 8080,
          instance_type: form.instance_type,
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.detail || 'Failed to create instance')
      setForm({ ...form, name: '' })
      await fetchInstances()
    } catch (e) {
      setError(e.message)
    } finally {
      setCreating(false)
    }
  }

  async function handleAction(name, action) {
    setBusyName(name)
    setError(null)
    try {
      const method = action === 'delete' ? 'DELETE' : 'POST'
      const path = action === 'delete' ? `/instances/${name}` : `/instances/${name}/${action}`
      const res = await fetch(`${API_BASE}${path}`, { method })
      const data = await res.json()
      if (!res.ok) throw new Error(data.detail || `Failed to ${action} instance`)
      await fetchInstances()
    } catch (e) {
      setError(e.message)
    } finally {
      setBusyName(null)
    }
  }

  async function showLogs(name) {
    setLogs({ name, text: '', loading: true })
    try {
      const res = await fetch(`${API_BASE}/instances/${name}/logs`)
      const data = await res.json()
      if (!res.ok) throw new Error(data.detail || 'Failed to fetch logs')
      setLogs({ name, text: data.logs || '(no output yet)', loading: false })
    } catch (e) {
      setLogs({ name, text: `Error: ${e.message}`, loading: false })
    }
  }

  const runningCount = instances.filter((i) => i.status === 'running').length
  const stoppedCount = instances.length - runningCount
  const dockerDown = health && health.docker === false

  return (
    <div className="app">
      <header className="header">
        <div>
          <p className="header-title">mini-ec2 / docker edition</p>
          <h1><span className="prompt">$</span> instance console</h1>
        </div>
        <div className="fleet-summary">
          <span><span className="dot running" />{runningCount} running</span>
          <span><span className="dot stopped" />{stoppedCount} stopped</span>
          {health && (
            <span className="health" title={health.detail}>
              <span className={`dot ${health.docker ? 'running' : 'danger'}`} />
              docker {health.docker ? 'up' : 'down'}
            </span>
          )}
        </div>
      </header>

      {dockerDown && (
        <div className="error-banner">⚠ Docker daemon unreachable — start Docker, then launches will work. ({health.detail})</div>
      )}
      {error && <div className="error-banner">⚠ {error}</div>}

      <div className="create-panel">
        <p className="create-panel-label">launch new instance</p>
        <form className="create-form" onSubmit={handleCreate}>
          <div className="field">
            <label htmlFor="name">name</label>
            <input
              id="name"
              placeholder="web-1"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              required
            />
          </div>
          <div className="field">
            <label htmlFor="image_key">image</label>
            <select
              id="image_key"
              value={form.image_key}
              onChange={(e) => setForm({ ...form, image_key: e.target.value })}
            >
              {(images.length ? images : [{ key: 'nginx' }]).map((img) => (
                <option key={img.key} value={img.key}>{img.key}</option>
              ))}
            </select>
          </div>
          <div className="field">
            <label htmlFor="port">port</label>
            <input
              id="port"
              type="number"
              placeholder="8080"
              value={form.port}
              onChange={(e) => setForm({ ...form, port: e.target.value })}
              disabled={!isNetworkService}
              title={isNetworkService ? '' : 'This image has no network service, so no port is published.'}
            />
          </div>
          <div className="field">
            <label htmlFor="instance_type">instance type</label>
            <select
              id="instance_type"
              value={form.instance_type}
              onChange={(e) => setForm({ ...form, instance_type: e.target.value })}
            >
              {(instanceTypes.length ? instanceTypes : [{ name: 't3.micro' }]).map((t) => (
                <option key={t.name} value={t.name}>{t.name}</option>
              ))}
            </select>
          </div>
          <button className="btn btn-primary" type="submit" disabled={creating}>
            {creating ? 'launching…' : 'launch'}
          </button>
        </form>
        {selectedImage?.description && (
          <p className="type-hint">{selectedImage.description}</p>
        )}
      </div>

      <p className="section-label">instances {loading && '· loading'}</p>

      {instances.length === 0 && !loading ? (
        <div className="empty-state">no instances yet — launch one above</div>
      ) : (
        <div className="instance-grid">
          {instances.map((inst) => (
            <div className="instance-card" key={inst.id}>
              <span className={`led ${inst.status}`} />
              <div className="instance-name-wrap">
                <div className="instance-name">{inst.name}</div>
                <div className="instance-id">{inst.id}</div>
              </div>
              <div className="instance-meta">
                {inst.image}
                <span className="type-badge">{inst.instance_type}</span>
              </div>
              <div className="instance-endpoint">
                {inst.url && inst.status === 'running' ? (
                  <a className="endpoint-link" href={inst.url} target="_blank" rel="noreferrer">
                    {inst.url.replace('http://', '')} ↗
                  </a>
                ) : (
                  <span className={`instance-status ${inst.status}`}>{inst.status}</span>
                )}
              </div>
              <div className="instance-actions">
                <button
                  className="btn btn-ghost"
                  disabled={busyName === inst.name}
                  onClick={() => showLogs(inst.name)}
                >
                  logs
                </button>
                {inst.status === 'running' ? (
                  <button
                    className="btn btn-ghost"
                    disabled={busyName === inst.name}
                    onClick={() => handleAction(inst.name, 'stop')}
                  >
                    stop
                  </button>
                ) : (
                  <button
                    className="btn btn-ghost"
                    disabled={busyName === inst.name}
                    onClick={() => handleAction(inst.name, 'start')}
                  >
                    start
                  </button>
                )}
                <button
                  className="btn btn-danger"
                  disabled={busyName === inst.name}
                  onClick={() => handleAction(inst.name, 'delete')}
                >
                  delete
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {logs && (
        <div className="logs-overlay" onClick={() => setLogs(null)}>
          <div className="logs-modal" onClick={(e) => e.stopPropagation()}>
            <div className="logs-header">
              <span>console output · <strong>{logs.name}</strong></span>
              <button className="btn btn-ghost" onClick={() => setLogs(null)}>close</button>
            </div>
            <pre className="logs-body">{logs.loading ? 'loading…' : logs.text}</pre>
          </div>
        </div>
      )}
    </div>
  )
}
